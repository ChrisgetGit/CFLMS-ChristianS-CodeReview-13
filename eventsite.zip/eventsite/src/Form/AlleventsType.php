<?php

namespace App\Form;

use App\Entity\Allevents;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AlleventsType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name')
            ->add('eventdate')
            ->add('description')
            ->add('image')
            ->add('capacity')
            ->add('phonenumber')
            ->add('adress')
            ->add('url')
            ->add('type')
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Allevents::class,
        ]);
    }
}
