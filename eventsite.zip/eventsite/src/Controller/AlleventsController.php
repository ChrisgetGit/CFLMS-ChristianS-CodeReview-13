<?php

namespace App\Controller;

use App\Entity\Allevents;
use App\Form\AlleventsType;
use App\Repository\AlleventsRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/allevents")
 */
class AlleventsController extends AbstractController
{
    /**
     * @Route("/", name="allevents_index", methods={"GET"})
     */
    public function index(AlleventsRepository $alleventsRepository): Response
    {
        return $this->render('allevents/index.html.twig', [
            'allevents' => $alleventsRepository->findAll(),
        ]);
    }

    /**
     * @Route("/new", name="allevents_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $allevent = new Allevents();
        $form = $this->createForm(AlleventsType::class, $allevent);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($allevent);
            $entityManager->flush();

            return $this->redirectToRoute('allevents_index');
        }

        return $this->render('allevents/new.html.twig', [
            'allevent' => $allevent,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="allevents_show", methods={"GET"})
     */
    public function show(Allevents $allevent): Response
    {
        return $this->render('allevents/show.html.twig', [
            'allevent' => $allevent,
        ]);
    }

    /**
     * @Route("/{id}/edit", name="allevents_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Allevents $allevent): Response
    {
        $form = $this->createForm(AlleventsType::class, $allevent);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('allevents_index');
        }

        return $this->render('allevents/edit.html.twig', [
            'allevent' => $allevent,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="allevents_delete", methods={"DELETE"})
     */
    public function delete(Request $request, Allevents $allevent): Response
    {
        if ($this->isCsrfTokenValid('delete'.$allevent->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($allevent);
            $entityManager->flush();
        }

        return $this->redirectToRoute('allevents_index');
    }


    /**
     * @Route("/music", name="allevents_music", methods={"GET"})
     */
    public function indexmusic(AlleventsRepository $alleventsRepository): Response
    {
        return $this->render('allevents/music.html.twig', [
            'allevents' => $alleventsRepository->findAll(),
        ]);
    }


}
